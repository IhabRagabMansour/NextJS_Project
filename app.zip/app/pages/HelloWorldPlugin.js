export default function HelloWorldPlugin() {
    return (
        <p> Hello World hoooosdfk.n </p>
    );
}