import React from 'react';
import Header from '../components/graphicalView/Header';
import Body from '../components/graphicalView/Body';
import "../globals.css";

function GraphicalVew() {
  return (
    <div className='font-sans leading-6 m-0'>
      <Header />
      <Body />

    </div>
  )
}

export default GraphicalVew
