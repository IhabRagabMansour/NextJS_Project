"use client"
import LeftSideBar from "./components/LeftSideBar/LeftSideBar"
import HelloWorldPlugin from "./pages/HelloWorldPlugin"
import GraphicalVew from "./pages/GraphicalVew";
import { useState } from "react";

export default function Home() {
  const [activePage, setActivePage] = useState(0);
  const onMenuItemClick = (pageIndex) => {
    setActivePage(pageIndex);
  };

  const MainBody = () => {
    switch (activePage) {
      case 0:
        return <GraphicalVew />;
      default:
        return null;
    }
  };

  return (
    <div className="flex">
      <div id="LeftSideBar" className="h-screen fixed left-0 w-28 bg-gray-50 border-r border-gray-200">
        <LeftSideBar onMenuItemClick={onMenuItemClick} ActiveButtonIndex={activePage} />
      </div>
      <div className="w-full ml-28 ">
        {MainBody()}
      </div>
    </div >
  )
}
