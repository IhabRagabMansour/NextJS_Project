const LeftSideBarItems = ['Graphical View', 'Tabular View'];
export default LeftSideBarItems;
