import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlay, faReply, faFileExport, faDownload, faTable, faPlus, faChartColumn } from '@fortawesome/free-solid-svg-icons';

function Header() {
  return (
    <header className='w-full bg-blue-400 p-2.5' >
      <div className="w-full">
        <div className="flex">
          {/* Font Awesome icons */}
          <span className="mr-4"><FontAwesomeIcon icon={faPlay} size="2x" /></span>
          <span className="mr-4"><FontAwesomeIcon icon={faReply} size="2x" /></span>
          <span className="mr-4"><FontAwesomeIcon icon={faFileExport} size="2x" /></span>
          <span className="mr-4"><FontAwesomeIcon icon={faDownload} size="2x" /></span>
          <span className="mr-4"><FontAwesomeIcon icon={faTable} size="2x" /></span>
          <span className="mr-4"><FontAwesomeIcon icon={faPlus} size="2x" /></span>
          <span className="mr-4"><FontAwesomeIcon icon={faChartColumn} size="2x" /></span>
        </div>
      </div>
    </header>
  );
}



export default Header;
