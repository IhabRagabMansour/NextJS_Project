import React from 'react'
import LeftPanel from './LeftPanel';
import RightPanel from './RightPanel';
function Body() {
  return (
    <div className="flex w-full h-screen">
      <LeftPanel />
      <RightPanel />
    </div>
  )
}

export default Body
