import React from 'react';
import Process from './Process';

const BCCouple = ({ leftName, rightName, arrowNumber, idx }) => {
  return (
    <div className={`flex items-center justify-center ${idx == 0 ? '' : 'pl-4'}`}>
      <Process name={leftName} />
      <div className="mx-4 flex flex-col  items-center">
        <span className="font-medium  text-lg">{arrowNumber}</span>
        <svg width="60" height="20" viewBox="0 0 60 20" xmlns="http://www.w3.org/2000/svg">
          <path d="M0 10 L10 0 L10 20 Z" fill="#000" />
          <line x1="10" y1="10" x2="50" y2="10" stroke="#000" strokeWidth="2" />
          <path d="M60 10 L50 0 L50 20 Z" fill="#000" />
        </svg>

      </div>
      <Process name={rightName} />
    </div>
  );
};

export default BCCouple;