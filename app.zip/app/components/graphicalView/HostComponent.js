import React from 'react';
import BCCouple from './BCCouple';

const HostComponent = ({ bcCouples }) => {
  return (
    <div className="flex flex-col space-y-4 p-4 bg-gray-100 rounded-md">
      <h2 className="text-xl font-semibold mb-4">Host 1</h2>
      <section className='flex gap-4 divide-x-2'>

        {bcCouples.map((couple, index) => (
          <BCCouple
            key={index}
            idx={index}
            leftName={couple.leftName}
            rightName={couple.rightName}
            arrowNumber={couple.arrowNumber}
          />
        ))}
      </section>
    </div>
  );
};

export default HostComponent;