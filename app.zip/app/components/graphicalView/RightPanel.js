import React from 'react';
import HostComponent from './HostComponent';
import Host from './Host';
import Monitor from './Monitor';
const hosts = [
  {
    name: "Host 1",
    status: "up",
    socketsNumber: 64,
    connectedProcesses: "A & B1",
    dataRate: "20Mib/sec",
  },
  {
    name: "Host 2",
    status: "down",
    socketsNumber: 128,
    connectedProcesses: "A & B2 ",
    dataRate: "10Mib/sec",
  },
  {
    name: "Host 3",
    status: "up",
    socketsNumber: 32,
    connectedProcesses: "A & B3",
    dataRate: "40Mib/sec",
  }
]




function RightPanel() {
  const bcCouplesData = [
    { leftName: 'B1', rightName: 'C1', arrowNumber: 32 },
    { leftName: 'B2', rightName: 'C2', arrowNumber: 64 },
    { leftName: 'B3', rightName: 'C3', arrowNumber: 16 },
    { leftName: 'B4', rightName: 'C4', arrowNumber: 32 },

    // Add more objects for additional rows as needed
  ];

  const monitorData = {
    processLabel: 'A',
    hostsData: [
      {
        arrowNumber: 1,
        bcCouples: [
          { leftName: 'B1', rightName: 'C1', arrowNumber: 32 },
          // ...more BCCoupleComponent data for Host 1
        ],
      },
      {
        arrowNumber: 3,
        bcCouples: [
          { leftName: 'B2', rightName: 'C2', arrowNumber: 40 },
          // ...more BCCoupleComponent data for Host 2
        ],
      },
      {
        arrowNumber: 1,
        bcCouples: [
          { leftName: 'B3', rightName: 'C3', arrowNumber: 64 },
          // ...more BCCoupleComponent data for Host 3
        ],
      },
      {
        arrowNumber: 1,
        bcCouples: [
          { leftName: 'B4', rightName: 'C4', arrowNumber: 32 },
          // ...more BCCoupleComponent data for Host 3
        ],
      }
      // ...more hosts data
    ],
  };
  return (
    <div className="h-full w-1/3 p-5">
      <div className="p-5">
        {hosts.map((host) => (
          <Host hostData={host} key={host.name} />
        ))}
      </div>
      {/* <HostComponent bcCouples={bcCouplesData} />
      {/* <Monitor processLabel={monitorData.processLabel} hostsData={monitorData.hostsData} /> */}
    </div>



  )
}

export default RightPanel
