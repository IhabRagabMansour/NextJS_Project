import React from "react";
import { useState, useCallback } from "react";
import Monitor from "./Monitor";

function LeftPanel() {
  const [scale, setScale] = useState(1);

  const handleWheel = useCallback((event) => {
    if (event.deltaY < 0) {
      // Zoom in
      setScale((prevScale) => prevScale + 0.05);
    } else if (event.deltaY > 0) {
      // Zoom out
      setScale((prevScale) => Math.max(prevScale - 0.05, 0.05)); // Prevent scale from going below 0.1
    }
  }, []);

  const [isDragging, setIsDragging] = useState(false);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [origin, setOrigin] = useState({ x: 0, y: 0 });

  const handleMouseDown = useCallback((event) => {
    setIsDragging(true);
    setOrigin({
      x: event.clientX - position.x,
      y: event.clientY - position.y,
    });
  }, [position]);

  const handleMouseMove = useCallback(
    (event) => {
      if (isDragging) {
        setPosition({
          x: event.clientX - origin.x,
          y: event.clientY - origin.y,
        });
      }
    },
    [isDragging, origin]
  );

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);


  const monitorData = {
    processLabel: 'A',
    hostsData: [
      {
        arrowNumber: 1,
        bcCouples: [
          { leftName: 'B1', rightName: 'C1', arrowNumber: 32 },
          { leftName: 'B1', rightName: 'C1', arrowNumber: 32 },
          { leftName: 'B1', rightName: 'C1', arrowNumber: 32 },
          // ...more BCCoupleComponent data for Host 1
        ],
      },
      {
        arrowNumber: 3,
        bcCouples: [
          { leftName: 'B2', rightName: 'C2', arrowNumber: 40 },
          // ...more BCCoupleComponent data for Host 2
        ],
      },
      {
        arrowNumber: 1,
        bcCouples: [
          { leftName: 'B3', rightName: 'C3', arrowNumber: 64 },
          // ...more BCCoupleComponent data for Host 3
        ],
      },
      {
        arrowNumber: 1,
        bcCouples: [
          { leftName: 'B4', rightName: 'C4', arrowNumber: 32 },
          // ...more BCCoupleComponent data for Host 3
        ],
      },
      {
        arrowNumber: 1,
        bcCouples: [
          { leftName: 'B4', rightName: 'C4', arrowNumber: 32 },
          // ...more BCCoupleComponent data for Host 3
        ],
      }
      // ...more hosts data
    ],
  };

  return (


    <div className=" h-full w-2/3   p-5 overflow-x-auto "
      onWheel={handleWheel}

    >
      <div onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        style={{
          cursor: isDragging ? 'grabbing' : 'grab',
          transform: `translate(${position.x}px, ${position.y}px)`,
        }}
      >


        <div className="min-w-max space-x-4 py-4 flex"

          style={{ transform: `scale(${scale})`, transformOrigin: '0 0' }}


        >
          {/* Repeat this section for each graph you want to display */}
          <div className="graph-container bg-white p-4 rounded-lg shadow-md flex-none">
            {/* Content of your graph here */}
            <Monitor processLabel={monitorData.processLabel} hostsData={monitorData.hostsData} />

          </div>


        </div>
      </div>
    </div>

  )
}

export default LeftPanel


// <div className="h-full w-2/3 border-r border-black p-5 overflow-auto ">
//   <div className="flex flex-col flex-row space-y-4 py-4">


//     <img src="https://upload.wikimedia.org/wikipedia/commons/b/b6/Image_created_with_a_mobile_phone.png" alt="graph image" />
//     <img src="https://i.imgur.com/tZb9Y8d.png" width="250" hight="200" alt="graph image" />
//     <img src="https://i.imgur.com/tZb9Y8d.png" width="250" hight="200" alt="graph image" />
//     <img src="https://i.imgur.com/tZb9Y8d.png" width="250" hight="200" alt="graph image" />



//     <img src="https://i.imgur.com/tZb9Y8d.png" width="250" hight="200" alt="graph image" />
//     <img src="https://i.imgur.com/tZb9Y8d.png" width="250" hight="200" alt="graph image" />
//     <img src="https://i.imgur.com/tZb9Y8d.png" width="250" hight="200" alt="graph image" />
//     <img src="https://i.imgur.com/tZb9Y8d.png" width="250" hight="200" alt="graph image" />


//     <img src="https://i.imgur.com/tZb9Y8d.png" width="250" hight="200" alt="graph image" />
//     <img src="https://i.imgur.com/tZb9Y8d.png" width="250" hight="200" alt="graph image" />
//     <img src="https://i.imgur.com/tZb9Y8d.png" width="250" hight="200" alt="graph image" />
//   </div>


// </div>


//   < div className = "graph-container bg-white p-4 rounded-lg shadow-md flex-none" >
//     {/* Content of your graph here */ }
//     < img src = "https://i.imgur.com/tZb9Y8d.png" width = "250" hight = "200" alt = "graph image" />
//             <img src="https://i.imgur.com/tZb9Y8d.png" width="250" hight="200" alt="graph image" />
//             <img src="https://i.imgur.com/tZb9Y8d.png" width="250" hight="200" alt="graph image" />
//           </ >

//           <div className="graph-container bg-white p-4 rounded-lg shadow-md flex-none">
//             {/* Content of your graph here */}
//             <img src="https://i.imgur.com/tZb9Y8d.png" width="250" hight="200" alt="graph image" />
//             <img src="https://i.imgur.com/tZb9Y8d.png" width="250" hight="200" alt="graph image" />
//             <img src="https://i.imgur.com/tZb9Y8d.png" width="250" hight="200" alt="graph image" />
//           </div>

//           <div className="graph-container bg-white p-4 rounded-lg shadow-md flex-none">
//             {/* Content of your graph here */}
//             <img src="https://i.imgur.com/tZb9Y8d.png" width="250" hight="200" alt="graph image" />
//             <img src="https://i.imgur.com/tZb9Y8d.png" width="250" hight="200" alt="graph image" />
//             <img src="https://i.imgur.com/tZb9Y8d.png" width="250" hight="200" alt="graph image" />
//           </div>
// {/* ... Other graph containers */ }