
import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faServer } from '@fortawesome/free-solid-svg-icons';
const Process = ({ name }) => {
  return (
    <div className="flex flex-col items-center justify-center bg-blue-400 rounded-lg p-4">
      {/* Replace the div below with the actual icon you want to use */}
      <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
        {/* Icon placeholder */}
        <span><FontAwesomeIcon icon={faServer} size='2x' /> </span>
      </div>
      <span className="mt-2 text-sm">{name}</span>
    </div>
  );
};

export default Process;