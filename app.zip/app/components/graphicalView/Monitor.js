import React from 'react';
import HostComponent from './HostComponent';
import Process from './Process';

const Monitor = ({ processLabel, hostsData }) => {
  return (
    <div className="flex ">
      {/* Process component for the "A" process */}
      <div className="flex flex-col justify-center items-center mr-6 pr-20">
        <Process name={processLabel} />
        {/* You can add more structure here if needed */}
      </div>

      {/* Container for hosts and arrows */}
      <div className="flex flex-col  justify-center pl-20 ml-20">
        {hostsData.map((host, index) => {
          const dataLength = hostsData.length;
          const dataIsEven = !(dataLength % 2);

          const hostCardHeight = 200;
          const gap = 15;

          const middleIndex = Math.floor(dataLength / 2);
          let shiftedIndex = Math.abs(index - middleIndex);
          if (dataIsEven)
            shiftedIndex = index < middleIndex ? Math.abs(shiftedIndex - 1) : shiftedIndex;

          let oppositeSide = 1;
          if (dataIsEven)
            oppositeSide = gap / 2 + hostCardHeight / 2 + ((gap + hostCardHeight) * shiftedIndex);
          else
            oppositeSide = + ((gap + hostCardHeight) * (shiftedIndex));

          const adjacentSide = 250; // constant
          const hypotenuse = Math.sqrt(oppositeSide * oppositeSide + adjacentSide * adjacentSide);

          const angle = Math.atan(oppositeSide / adjacentSide);

          const isBeforeHalf = index < (dataLength / 2);
          return (
            <div key={index} className="flex items-center mb-4 relative">
              {/* SVG for double-ended arrow with number */}
              <div className="flex flex-col items-center absolute origin-[right_bottom]"
                style={{
                  width: hypotenuse + 'px',
                  left: (-1 * (hypotenuse + 10)) + 'px',
                  rotate: isBeforeHalf ? (-1 * angle) + 'rad' : angle + 'rad'
                }}
              >
                <span className="text-lg font-medium mb-1">{host.arrowNumber}</span>
                <div className='h-1 w-full bg-black arrow'>
                </div>
              </div>
              {/* Host component */}
              <HostComponent bcCouples={host.bcCouples} />
            </div>
          )
        })}
      </div>
    </div>
  );
};

export default Monitor;